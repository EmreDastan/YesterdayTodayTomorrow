package derspackage;

import java.util.Scanner;

public class DersClass {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please write today's name in English : ");
		String a = scan.nextLine();
		days(a);
	}
	public static String days(String a) {
		
		if (a.equalsIgnoreCase("Monday")) {
			System.out.println("Yesterday was Sunday\nTomorrow is Tuesday.");
		}
		else if (a.equalsIgnoreCase("Tuesday")) {
			System.out.println("Yesterday was Monday\nTomorrow is Wednesday.");
		}
		else if (a.equalsIgnoreCase("Wednesday")) {
			System.out.println("Yesterday was Tuesday\nTomorrow is Thursday.");
		}
		else if (a.equalsIgnoreCase("Thursday")) {
			System.out.println("Yesterday was Wednesday\nTomorrow is Friday.");
		}
		else if (a.equalsIgnoreCase("Friday")) {
			System.out.println("Yesterday was Thursday\nTomorrow is Saturday.");
		}
		else if (a.equalsIgnoreCase("Saturday")) {
			System.out.println("Yesterday was Friday\nTomorrow is Sunday.");
		}
		else if (a.equalsIgnoreCase("Sunday")) {
			System.out.println("Yesterday was Saturday\nTomorrow is Monday.");
		}
		return a;
	}
		
	
}